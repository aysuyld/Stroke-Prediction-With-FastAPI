from fastapi import FastAPI
import joblib
import numpy as np
from pydantic import BaseModel

app = FastAPI()

class InputData(BaseModel):
    gender: int
    age: int
    hypertension: int
    heart_disease: int
    ever_married: int
    work_type: int
    Residence_type: int
    avg_glucose_level: int
    bmi: int
    smoking_status: int
    
model = joblib.load("model_joblib")

@app.post("/stroke")
async def post(data: InputData):

    input_values = np.array([data.gender, data.age, data.hypertension, data.heart_disease, data.ever_married, data.work_type, data.Residence_type, data.avg_glucose_level, data.bmi, data.smoking_status]).tolist()

    
    print(input_values)

    try:
        pre = model.predict([input_values])
        if pre[0].item() == 0:
            return ("Felç geçirme ihtimali düşük")
        else:
            return ("Felç geçirme ihtimali yüksek")
        
        #return {"prediction": pre[0].item()}
    except:
        return {"message": "tahmin edemiyor"}
    

@app.get("/stroke/get")
async def get():
    return {"message": "Mesaj"}


import uvicorn

if __name__ == "__main__":
    uvicorn.run(app)
